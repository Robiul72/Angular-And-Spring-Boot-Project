export class User{
    fullname: string = '' 
    username: string = ''
    password: string = ''
    loggedIn: boolean = false;
}